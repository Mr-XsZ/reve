# DOWNLOAD TERMUX
1. BUKA PLAY STORE
2. KETIK "TERMUX" DI PENCARIAN
3. DOWNLOAD TERMUX

# INSTALASI/PEMASANGAN/SETUP
1. BUKA TERMUX
2. KETIK "pkg install python" di termux
3. Enter
4. Tunggu beberapa saat sampai ada pilihan (y or n) . Ketik "y"
5. Enter
6. KETIK "pkg install git" di termux
7. Enter
8. Tunggu beberapa saat sampai ada pilihan (y or n) . Ketik "y"
9. Enter
10. Ketik "pip install --upgrade pip" di termux
11. Enter
12. Ketik "pip install requests" di termux
13. Enter
14. Ketik "pip install websocket-client" di termux
15. Enter
16. Ketik "pip install googletrans" di termux
17. Enter

# PEMASANGAN SCRIPT
1. KETIK "git clone https://github.com/diverglovsky/vvvip/" di termux
2. Enter

# MEMAKAI SCRIPT TOOLS 26
1. BUKA TERMUX
2. KETIK "cd vvvip"
3. Enter
4. Ketik "python vvvip.py"
5. Enter

# MEMAKAI SCRIPT SPAM
1. BUKA TERMUX
2. KETIK "cd vvvip"
3. Enter
4. Ketik "python spam.py"
5. Enter
